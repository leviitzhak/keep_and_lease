"""Offline inference + independent reference restoration; no training or network."""
import gzip
import json
from pathlib import Path
import sys
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "inference-source"))
import numpy as np
import torch
from research.post_decision_value.treasury_model import load_scalar
from research.post_decision_value.treasury_fixtures import hold_reference
torch.set_num_threads(1)
identity = json.loads((root / "identity.json").read_text())
model, _, _ = load_scalar(root / "selected-model.pt", identity)
examples = json.loads((root / "inference-examples.json").read_text())
np.testing.assert_allclose(model.predict(examples["features"]), examples["predictions"], rtol=0, atol=1e-8)
cases = {c["id"]: c for cs in json.loads((root / "fixtures.json").read_text()).values() for c in cs}
rows = json.loads(gzip.decompress((root / "diagnosis-train.json.gz").read_bytes()))
for r in rows:
    ref = hold_reference(cases[r["case"]], r["quantity"], r["horizon_ms"], inventory=r["kind"]=="boundary")
    assert abs(ref["utility"]-r["target"]) < 1e-8
print(json.dumps(dict(verified=True, model=model.fingerprint(), target_version=model.target_version, inference_examples=len(examples["features"]), independent_references=len(rows))))
